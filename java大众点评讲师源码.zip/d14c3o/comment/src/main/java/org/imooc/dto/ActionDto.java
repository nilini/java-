package org.imooc.dto;

import org.imooc.bean.Action;

public class ActionDto extends Action {

}