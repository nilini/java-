package org.imooc.dto;

import org.imooc.bean.Menu;

public class MenuDto extends Menu {
	
}