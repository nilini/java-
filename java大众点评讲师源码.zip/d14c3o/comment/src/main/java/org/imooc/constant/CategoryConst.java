package org.imooc.constant;

/**
 * 商户类别相关常量定义
 */
public class CategoryConst {
    public static final String ALL = "all";
}