package org.imooc.constant;

public interface SysParamKeyConst {
	
	/**
	 * 最后一次同步星级时间
	 */
	public static final String LAST_SYNC_STAR_TIME = "last_sync_star_time";
}