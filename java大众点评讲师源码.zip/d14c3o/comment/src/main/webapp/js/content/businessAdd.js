function add() {
	$("#mainForm").submit();
}