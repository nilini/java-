function modify() {
	$("#mainForm").submit();
}